<div class="container-fluid">
  <div class="header-social row justify-content-end">
    <div class="col-md-auto"><!-- faceboobk-->
      <a href ="http://www.facebook.com/sharer.php?u=<?php echo $actual_link;?>" target="_blank"/><img src="https://techhobbyist.co.uk/wp-content/themes/thetechhobbiest/assets/images/facebook_icon.png"/></a>
    </div>
    <div class="col-md-auto"><!-- Twitter -->
            <a href ="http://twitter.com/share?u=<?php echo $actual_link;?>&text=Simple Share Buttons&hashtags=simplesharebuttons" target="_blank"/><img src="https://techhobbyist.co.uk/wp-content/themes/thetechhobbiest/assets/images/twitter.png"/></a>

    </div>
    <div class="col-md-auto"><!-- Reddit -->
            <a href ="http://reddit.com/submit?url=<?php echo $actual_link;?>&title=Simple Share Buttons" target="_blank"/><img src="https://techhobbyist.co.uk/wp-content/themes/thetechhobbiest/assets/images/facebook_icon.png"/></a>

    </div><!-- LinkedIn -->
    <div class="col-md-auto">
           <a href ="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $actual_link;?>" target="_blank"/><img src="https://techhobbyist.co.uk/wp-content/themes/thetechhobbiest/assets/images/facebook_icon.png"/></a>

    </div>
    </div><!-- LinkedIn -->
    <div class="col-md-auto">
           <a href ="mailto:?Subject=Simple Share Buttons&Body=I%20saw%20this%20and%20thought%20of%20you!%20<?php echo $actual_link;?>" target="_blank"/><img src="https://techhobbyist.co.uk/wp-content/themes/thetechhobbiest/assets/images/facebook_icon.png"/></a>

    </div>
  </div>
  </div>
